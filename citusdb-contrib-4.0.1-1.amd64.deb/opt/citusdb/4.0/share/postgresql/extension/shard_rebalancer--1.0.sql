/* contrib/shard_rebalancer/shard_rebalancer--1.0.sql */

-- complain if script is sourced in psql, rather than via CREATE EXTENSION
\echo Use "CREATE EXTENSION shard_rebalancer" to load this file. \quit

CREATE FUNCTION shard_placement_rebalance_array(worker_node_list json[],
												shard_placement_list json[],
												threshold float4)
RETURNS json[]
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT VOLATILE;

CREATE FUNCTION shard_placement_replication_array(worker_node_list json[],
												  shard_placement_list json[],
												  shard_replication_factor int)
RETURNS json[]
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT VOLATILE;

CREATE FUNCTION worker_node_responsive(worker_node_name text, worker_node_port int)
RETURNS boolean
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT VOLATILE;

CREATE FUNCTION update_shard_placement(placement_update_data json,
									   relation regclass,
									   responsive_node_list json[])
RETURNS boolean
AS 'MODULE_PATHNAME'
LANGUAGE C STRICT VOLATILE;

-- Create master_get_active_worker_nodes() if it doesn't exist
DO $$
BEGIN
    PERFORM 'master_get_active_worker_nodes()'::regprocedure;
EXCEPTION
    WHEN undefined_function THEN
        CREATE FUNCTION master_get_active_worker_nodes()
        RETURNS TABLE (node_name text, node_port bigint)
        AS 'MODULE_PATHNAME'
        LANGUAGE C STRICT VOLATILE;
END;
$$ LANGUAGE 'plpgsql';

--
-- rebalance_table_shards uses the shard rebalancer's C UDF functions to rebalance
-- shards of the given relation.
--
CREATE FUNCTION rebalance_table_shards(relation regclass,
                                       threshold float4 default 0.1,
                                       max_shard_moves int default 1000000,
                                       excluded_shard_list bigint[] default '{}')
RETURNS VOID AS $$
DECLARE
    lock_acquired boolean;
    shard_placement_list json[];
    worker_node_list json[];
    responsive_node_list json[];
    rebalance_placement_update_list json[];
    placement_update_data json;

BEGIN
    SELECT pg_try_advisory_xact_lock(relation::bigint) INTO lock_acquired;
    IF NOT lock_acquired THEN
        RAISE EXCEPTION 'could not acquire the lock for rebalancing or replicating %',
                        relation;
    END IF;

    -- get shard placement list
    SELECT array_agg(to_json(placement)) INTO shard_placement_list
    FROM
    (
        SELECT
            pg_dist_shard_placement.oid, pg_dist_shard_placement.*
        FROM
            pg_dist_shard, pg_dist_shard_placement
        WHERE
            pg_dist_shard.shardid = pg_dist_shard_placement.shardid AND
            NOT excluded_shard_list @> ARRAY[pg_dist_shard.shardid] AND
            pg_dist_shard.logicalrelid = relation
    ) placement;

    -- get worker node list
    SELECT
        array_agg(to_json(worker_node)) INTO worker_node_list
    FROM
        master_get_active_worker_nodes() worker_node;

    -- get responsive node list
    SELECT
        array_agg(to_json(worker_node)) INTO responsive_node_list
    FROM
        master_get_active_worker_nodes() worker_node
    WHERE
        worker_node_responsive(worker_node.node_name, worker_node.node_port::int);

    -- get rebalance array
    rebalance_placement_update_list :=
        (shard_placement_rebalance_array(worker_node_list, shard_placement_list,
                                         threshold))[1:max_shard_moves];

    -- move shard placements
    FOR placement_update_data IN SELECT unnest(rebalance_placement_update_list) LOOP
        RAISE NOTICE 'Moving shard % from %:% to %:% ...',
                     placement_update_data->>'shardid',
                     placement_update_data->>'sourcename',
                     placement_update_data->>'sourceport',
                     placement_update_data->>'targetname',
                     placement_update_data->>'targetport';

        PERFORM update_shard_placement(placement_update_data, relation,
                                       responsive_node_list);

    END LOOP;
END;
$$ LANGUAGE 'plpgsql';


--
-- replicate_table_shards uses the shard rebalancer's C UDF functions to replicate
-- under-replicated shards of the given table.
--
CREATE FUNCTION replicate_table_shards(relation regclass,
                                       shard_replication_factor int
                                       default current_setting('shard_replication_factor')::int,
                                       max_shard_copies int default 1000000,
                                       excluded_shard_list bigint[] default '{}')
RETURNS VOID AS $$
DECLARE
    lock_acquired boolean;
    shard_placement_list json[];
    worker_node_list json[];
    responsive_node_list json[];
    replicate_placement_update_list json[];
    placement_update_data json;

BEGIN
    SELECT pg_try_advisory_xact_lock(relation::bigint) INTO lock_acquired;
    IF NOT lock_acquired THEN
        RAISE EXCEPTION 'could not acquire the lock for rebalancing or replicating %',
                        relation;
    END IF;

    -- get shard placement list
    SELECT array_agg(to_json(placement)) INTO shard_placement_list
    FROM
    (
        SELECT
            pg_dist_shard_placement.oid, pg_dist_shard_placement.*
        FROM
            pg_dist_shard, pg_dist_shard_placement
        WHERE
            pg_dist_shard.shardid = pg_dist_shard_placement.shardid AND
            NOT excluded_shard_list @> ARRAY[pg_dist_shard.shardid] AND
            pg_dist_shard.logicalrelid = relation
    ) placement;

    -- get worker node list
    SELECT
        array_agg(to_json(worker_node)) INTO worker_node_list
    FROM
        master_get_active_worker_nodes() worker_node;

    -- get responsive node list
    SELECT
        array_agg(to_json(worker_node)) INTO responsive_node_list
    FROM
        master_get_active_worker_nodes() worker_node
    WHERE
        worker_node_responsive(worker_node.node_name, worker_node.node_port::int);

    -- get replication array
    replicate_placement_update_list :=
        (shard_placement_replication_array(worker_node_list,
                                           shard_placement_list,
                                           shard_replication_factor))[1:max_shard_copies];

    -- move shard placements
    FOR placement_update_data IN SELECT unnest(replicate_placement_update_list) LOOP
        RAISE NOTICE 'Copying shard % from %:% to %:% ...',
                     placement_update_data->>'shardid',
                     placement_update_data->>'sourcename',
                     placement_update_data->>'sourceport',
                     placement_update_data->>'targetname',
                     placement_update_data->>'targetport';

        PERFORM update_shard_placement(placement_update_data, relation,
                                       responsive_node_list);

    END LOOP;
END;
$$ LANGUAGE 'plpgsql';
